#!/bin/bash
pdflatex formel.tex  
#pdflatex formel.tex
#pdflatex formel.tex
rm *.aux 
rm *.log
rm *.toc
rm *~